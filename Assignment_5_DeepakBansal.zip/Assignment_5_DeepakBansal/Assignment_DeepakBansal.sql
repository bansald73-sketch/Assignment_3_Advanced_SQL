/* ============================================================
   Author  : Deepak B
   Email   : bansald73@gmail.com
   Created : 2026-10-07
   Updated : 2026-10-08
   Purpose : TuteDude Assignment 5 - Transactions, Logic & Analysis
   DBMS    : MySQL 8.0+ (CTE and window functions need 8.0+)
   ============================================================ */

-- ------------------------------------------------------------
-- SETUP: Database, tables and sample data
-- ------------------------------------------------------------
DROP DATABASE IF EXISTS assignment5_db;
CREATE DATABASE assignment5_db;
USE assignment5_db;

CREATE TABLE departments (
    dept_id   INT PRIMARY KEY,
    dept_name VARCHAR(50) NOT NULL
);

CREATE TABLE employees (
    emp_id     INT PRIMARY KEY,
    emp_name   VARCHAR(50) NOT NULL,
    dept_id    INT,
    manager_id INT NULL,
    salary     DECIMAL(10,2) NOT NULL CHECK (salary >= 0),
    FOREIGN KEY (dept_id)    REFERENCES departments(dept_id),
    FOREIGN KEY (manager_id) REFERENCES employees(emp_id)
);

INSERT INTO departments (dept_id, dept_name) VALUES
(1, 'IT'),
(2, 'HR'),
(3, 'Finance'),
(4, 'Legal');          -- Legal me koi employee nahi (EXISTS demo ke liye)

-- Manager pehle insert karna zaroori hai (self-referencing FK)
INSERT INTO employees (emp_id, emp_name, dept_id, manager_id, salary) VALUES
(1, 'Amit Sharma',  1, NULL, 90000),   -- CEO / top level
(2, 'Neha Verma',   1, 1,    70000),
(3, 'Rahul Singh',  1, 2,    50000),
(4, 'Priya Patel',  2, 1,    60000),
(5, 'Karan Mehta',  2, 4,    45000),
(6, 'Sneha Joshi',  3, 1,    65000),
(7, 'Vikram Rao',   3, 6,    48000),
(8, 'Anjali Gupta', 1, 2,    52000);

SELECT * FROM departments;
SELECT * FROM employees;


-- ------------------------------------------------------------
-- TASK 1: Transaction to transfer 1000 from one employee to another
-- Amit Sharma (emp_id 1) -> Rahul Singh (emp_id 3)
-- ------------------------------------------------------------

-- Before
SELECT emp_id, emp_name, salary FROM employees WHERE emp_id IN (1, 3);

START TRANSACTION;

    -- Sender ki salary se 1000 minus (sirf tab jab balance kaafi ho)
    UPDATE employees
    SET salary = salary - 1000
    WHERE emp_id = 1 AND salary >= 1000;

    -- Receiver ki salary me 1000 plus
    UPDATE employees
    SET salary = salary + 1000
    WHERE emp_id = 3;

    -- Dono updates theek lage to hi COMMIT, warna ROLLBACK
COMMIT;

-- After
SELECT emp_id, emp_name, salary FROM employees WHERE emp_id IN (1, 3);

-- Task 1 (extra): Rollback demo - data integrity prove karne ke liye
START TRANSACTION;
    UPDATE employees SET salary = salary - 1000 WHERE emp_id = 2;
    UPDATE employees SET salary = salary + 1000 WHERE emp_id = 5;
    SELECT emp_id, emp_name, salary FROM employees WHERE emp_id IN (2, 5);  -- transaction ke andar
ROLLBACK;
SELECT emp_id, emp_name, salary FROM employees WHERE emp_id IN (2, 5);      -- rollback ke baad (unchanged)

-- Task 1 (extra): Reusable stored procedure with error handling
DROP PROCEDURE IF EXISTS transfer_salary;
DELIMITER $$
CREATE PROCEDURE transfer_salary(
    IN p_from INT,
    IN p_to   INT,
    IN p_amt  DECIMAL(10,2)
)
BEGIN
    DECLARE v_sal DECIMAL(10,2);

    -- Koi bhi SQL error aaye to automatic rollback
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'Transfer failed - rolled back' AS status;
    END;

    START TRANSACTION;

    SELECT salary INTO v_sal FROM employees WHERE emp_id = p_from FOR UPDATE;

    IF v_sal IS NULL OR v_sal < p_amt THEN
        ROLLBACK;
        SELECT 'Insufficient salary or invalid employee - rolled back' AS status;
    ELSE
        UPDATE employees SET salary = salary - p_amt WHERE emp_id = p_from;
        UPDATE employees SET salary = salary + p_amt WHERE emp_id = p_to;
        COMMIT;
        SELECT 'Transfer successful' AS status;
    END IF;
END$$
DELIMITER ;

CALL transfer_salary(6, 7, 1000);
SELECT emp_id, emp_name, salary FROM employees WHERE emp_id IN (6, 7);


-- ------------------------------------------------------------
-- TASK 2: Departments with at least one employee (EXISTS)
-- ------------------------------------------------------------
SELECT d.dept_id, d.dept_name
FROM departments d
WHERE EXISTS (
    SELECT 1
    FROM employees e
    WHERE e.dept_id = d.dept_id
);
-- Output me Legal nahi aayega kyunki uska koi employee nahi hai


-- ------------------------------------------------------------
-- TASK 3: Recursive CTE - Employee-Manager hierarchy
-- ------------------------------------------------------------
WITH RECURSIVE emp_hierarchy AS (
    -- Anchor: top-level employee (jiska manager nahi hai)
    SELECT
        emp_id,
        emp_name,
        manager_id,
        CAST(NULL AS CHAR(50))         AS manager_name,
        0                              AS level,
        CAST(emp_name AS CHAR(500))    AS hierarchy_path
    FROM employees
    WHERE manager_id IS NULL

    UNION ALL

    -- Recursive part: har manager ke direct reports
    SELECT
        e.emp_id,
        e.emp_name,
        e.manager_id,
        h.emp_name                                   AS manager_name,
        h.level + 1                                  AS level,
        CONCAT(h.hierarchy_path, ' -> ', e.emp_name) AS hierarchy_path
    FROM employees e
    INNER JOIN emp_hierarchy h ON e.manager_id = h.emp_id
)
SELECT
    emp_id,
    CONCAT(REPEAT('    ', level), emp_name) AS employee,
    manager_name,
    level,
    hierarchy_path
FROM emp_hierarchy
ORDER BY hierarchy_path;


-- ------------------------------------------------------------
-- TASK 4: LEAD and LAG - previous and next salary
-- (salary ke ascending order me)
-- ------------------------------------------------------------
SELECT
    emp_id,
    emp_name,
    salary,
    LAG(salary)  OVER (ORDER BY salary, emp_id) AS previous_salary,
    LEAD(salary) OVER (ORDER BY salary, emp_id) AS next_salary
FROM employees
ORDER BY salary, emp_id;


-- ------------------------------------------------------------
-- TASK 5: Salary totals per department and overall (ROLLUP)
-- ------------------------------------------------------------
SELECT
    CASE
        WHEN GROUPING(d.dept_name) = 1 THEN 'GRAND TOTAL'
        ELSE d.dept_name
    END AS department,
    SUM(e.salary) AS total_salary
FROM employees e
JOIN departments d ON e.dept_id = d.dept_id
GROUP BY d.dept_name WITH ROLLUP;


-- ------------------------------------------------------------
-- TASK 6: Export database structure and data using mysqldump
-- NOTE: mysqldump MySQL client me nahi, Command Prompt / Terminal me chalta hai.
--       Neeche wali commands terminal me run karo aur screenshot lo.
-- ------------------------------------------------------------

-- Structure + data dono:
--   mysqldump -u root -p assignment5_db > assignment5_db_backup.sql

-- Sirf structure (no data):
--   mysqldump -u root -p --no-data assignment5_db > assignment5_db_structure.sql

-- Sirf data (no structure):
--   mysqldump -u root -p --no-create-info assignment5_db > assignment5_db_data.sql

-- Stored procedure bhi export karna ho to:
--   mysqldump -u root -p --routines assignment5_db > assignment5_db_full.sql

-- Restore karne ke liye:
--   mysql -u root -p -e "CREATE DATABASE assignment5_db_copy;"
--   mysql -u root -p assignment5_db_copy < assignment5_db_backup.sql

-- ============================ END ============================
