/* ==================================================
   Deepak B
   bansald73@gmail.com
   created: 2026-09-26
   updated: 2026-09-27
   ================================================== */

-- ==================================================
-- ASSIGNMENT 4: DATA MODIFICATION & INTEGRITY
-- ==================================================
-- Pehle ek Employees table bana rahe hain jisme kuch
-- sample data daalenge, taaki neeche wale 6 tasks
-- properly test ho sakein.
-- ==================================================


-- --------------------------------------------------
-- STEP 0: TABLE CREATION
-- --------------------------------------------------
DROP TABLE IF EXISTS Employees;

CREATE TABLE Employees (
    emp_id      INT PRIMARY KEY AUTO_INCREMENT,
    first_name  VARCHAR(50)  NOT NULL,
    last_name   VARCHAR(50)  NOT NULL,
    department  VARCHAR(50)  NOT NULL,
    salary      DECIMAL(10,2) NOT NULL
);

-- --------------------------------------------------
-- STEP 0: SAMPLE DATA INSERTION
-- --------------------------------------------------
-- Sales, Obsolete, aur baaki departments ka data daal
-- rahe hain, taaki UPDATE/DELETE/VIEW sab check ho sake.
-- --------------------------------------------------
INSERT INTO Employees (first_name, last_name, department, salary) VALUES
('Amit',    'Sharma',   'Sales',    45000.00),
('Rohit',   'Verma',    'Sales',    52000.00),
('Priya',   'Singh',    'Sales',    38000.00),
('Neha',    'Gupta',    'HR',       60000.00),
('Suresh',  'Yadav',    'HR',       85000.00),
('Kavita',  'Patel',    'IT',       92000.00),
('Manoj',   'Kumar',    'IT',       78000.00),
('Sunita',  'Reddy',    'Finance',  95000.00),
('Rakesh',  'Jha',      'Finance',  40000.00),
('Anjali',  'Mishra',   'Obsolete', 30000.00),
('Vikas',   'Chauhan',  'Obsolete', 32000.00);

-- Data check karne ke liye
SELECT * FROM Employees;


-- ==================================================
-- TASK 1: Update Salary of 'Sales' Department by 10%
-- ==================================================
-- UPDATE statement se existing records ki salary ko
-- 10% badha rahe hain, sirf Sales department ke liye.
-- ==================================================
UPDATE Employees
SET salary = salary * 1.10
WHERE department = 'Sales';

-- Result verify karne ke liye
SELECT emp_id, first_name, last_name, department, salary
FROM Employees
WHERE department = 'Sales';


-- ==================================================
-- TASK 2: Delete Employees in 'Obsolete' Department
-- ==================================================
-- DELETE statement se un employees ko remove kar rahe
-- hain jo ek purane / band ho chuke department me hain.
-- ==================================================
DELETE FROM Employees
WHERE department = 'Obsolete';

-- Verify karo ki Obsolete department ka koi data na bache
SELECT * FROM Employees;


-- ==================================================
-- TASK 3: View for High-Earning Employees (Salary > 80,000)
-- ==================================================
-- View ek virtual table hoti hai, jo ek SELECT query ke
-- result par based hoti hai. Isse baar baar complex query
-- likhne ki zaroorat nahi padti.
-- ==================================================
DROP VIEW IF EXISTS HighEarningEmployees;

CREATE VIEW HighEarningEmployees AS
SELECT emp_id, first_name, last_name, department, salary
FROM Employees
WHERE salary > 80000;

-- View ko query karke dekho
SELECT * FROM HighEarningEmployees;


-- ==================================================
-- TASK 4: CHECK Constraint to Ensure Salary > 0
-- ==================================================
-- CHECK constraint ensure karta hai ki column me sirf
-- valid data (yaha salary hamesha positive) hi aaye.
-- Note: MySQL 8.0.16+ me CHECK enforce hota hai.
-- ==================================================
ALTER TABLE Employees
ADD CONSTRAINT chk_salary_positive CHECK (salary > 0);

-- Test: ye query error dega kyunki salary negative hai
-- (isko screenshot ke liye try karo, fir rollback/skip kar dena)
-- INSERT INTO Employees (first_name, last_name, department, salary)
-- VALUES ('Test', 'Fail', 'IT', -5000);


-- ==================================================
-- TASK 5: Index on Employee Last Names
-- ==================================================
-- Index banane se last_name column par search/filter
-- operations fast ho jaate hain, especially bade dataset me.
-- ==================================================
CREATE INDEX idx_last_name
ON Employees (last_name);

-- Index ka use dikhane ke liye ek search query
SELECT * FROM Employees
WHERE last_name = 'Sharma';


-- ==================================================
-- TASK 6: Stored Procedure - Get Employees by Department
-- ==================================================
-- Stored procedure ek reusable block of SQL code hota hai,
-- jise ek single call se execute kar sakte hain.
-- ==================================================
DELIMITER //

CREATE PROCEDURE GetEmployeesByDepartment(IN dept_name VARCHAR(50))
BEGIN
    SELECT emp_id, first_name, last_name, department, salary
    FROM Employees
    WHERE department = dept_name;
END //

DELIMITER ;

-- Procedure ko call karke test karo
CALL GetEmployeesByDepartment('IT');
CALL GetEmployeesByDepartment('Finance');


-- ==================================================
-- END OF ASSIGNMENT 4
-- ==================================================
