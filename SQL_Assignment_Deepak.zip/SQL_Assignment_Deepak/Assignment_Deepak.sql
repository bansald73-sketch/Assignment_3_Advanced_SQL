/*
============================================================
  Name    : Deepak B
  Email   : bansald73@gmail.com
  Created : 2026-09-24
  Updated : 2026-09-25
============================================================
  Assignment 3: Advanced SQL Queries (TuteDude)
  Compatible with: MySQL 8.0+ / PostgreSQL / SQL Server
============================================================
*/

-- ============================================================
-- STEP 0: DATABASE SETUP
-- ============================================================
DROP DATABASE IF EXISTS assignment3_db;
CREATE DATABASE assignment3_db;
USE assignment3_db;

-- ============================================================
-- STEP 1: TABLE CREATION
-- ============================================================

-- Companies table
CREATE TABLE companies (
    company_id   INT PRIMARY KEY,
    company_name VARCHAR(100) NOT NULL
);

-- Departments table
CREATE TABLE departments (
    department_id   INT PRIMARY KEY,
    department_name VARCHAR(100) NOT NULL,
    company_id      INT,
    FOREIGN KEY (company_id) REFERENCES companies(company_id)
);

-- Employees table (manager_id references employee_id -> self join)
CREATE TABLE employees (
    employee_id   INT PRIMARY KEY,
    employee_name VARCHAR(100) NOT NULL,
    department_id INT,
    manager_id    INT NULL,
    salary        DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (department_id) REFERENCES departments(department_id),
    FOREIGN KEY (manager_id) REFERENCES employees(employee_id)
);

-- ============================================================
-- STEP 2: DATA INSERTION
-- ============================================================

-- Companies
INSERT INTO companies (company_id, company_name) VALUES
(1, 'TuteDude Pvt Ltd'),
(2, 'Bright Future Inc');

-- Departments
INSERT INTO departments (department_id, department_name, company_id) VALUES
(101, 'Engineering', 1),
(102, 'Human Resources', 1),
(103, 'Sales', 2),
(104, 'Marketing', 2);

-- Employees
-- NOTE: manager_id = NULL means the employee has no manager (e.g. CEO/Head)
INSERT INTO employees (employee_id, employee_name, department_id, manager_id, salary) VALUES
(1, 'Amit Sharma',    101, NULL, 95000.00),   -- No manager (Head of Engineering)
(2, 'Priya Verma',    101, 1,    75000.00),
(3, 'Rohit Singh',    101, 1,    68000.00),
(4, 'Sneha Gupta',    102, NULL, 60000.00),   -- No manager (Head of HR)
(5, 'Karan Mehta',    102, 4,    45000.00),
(6, 'Anjali Rao',     103, NULL, 72000.00),   -- No manager (Head of Sales)
(7, 'Vikram Joshi',   103, 6,    58000.00),
(8, 'Neha Kapoor',    104, NULL, 70000.00),   -- No manager (Head of Marketing)
(9, 'Suresh Nair',    104, 8,    50000.00),
(10,'Deepak Bansal',  101, 1,    82000.00);

-- ============================================================
-- TASK 1: LEFT JOIN - List Employees and Their Managers
-- (Includes employees who have no manager listed)
-- ============================================================
SELECT
    e.employee_id,
    e.employee_name        AS employee_name,
    e.salary,
    m.employee_name         AS manager_name
FROM employees e
LEFT JOIN employees m
    ON e.manager_id = m.employee_id
ORDER BY e.employee_id;


-- ============================================================
-- TASK 2: Subquery - Employees Earning Above Average Salary
-- ============================================================
SELECT
    employee_id,
    employee_name,
    salary
FROM employees
WHERE salary > (
    SELECT AVG(salary) FROM employees
)
ORDER BY salary DESC;


-- ============================================================
-- TASK 3: Nested JOIN - Employee Name, Department, and Company
-- ============================================================
SELECT
    e.employee_name,
    d.department_name,
    c.company_name
FROM employees e
JOIN departments d
    ON e.department_id = d.department_id
JOIN companies c
    ON d.company_id = c.company_id
ORDER BY c.company_name, d.department_name, e.employee_name;


-- ============================================================
-- TASK 4: CTE - Find the Employee with the Second-Highest Salary
-- ============================================================
WITH RankedSalaries AS (
    SELECT
        employee_id,
        employee_name,
        salary,
        DENSE_RANK() OVER (ORDER BY salary DESC) AS salary_rank
    FROM employees
)
SELECT
    employee_id,
    employee_name,
    salary
FROM RankedSalaries
WHERE salary_rank = 2;


-- ============================================================
-- TASK 5: Rank Employees by Salary Within Each Department
-- (Using RANK and DENSE_RANK window functions)
-- ============================================================
SELECT
    e.employee_id,
    e.employee_name,
    d.department_name,
    e.salary,
    RANK()       OVER (PARTITION BY e.department_id ORDER BY e.salary DESC) AS salary_rank,
    DENSE_RANK() OVER (PARTITION BY e.department_id ORDER BY e.salary DESC) AS salary_dense_rank
FROM employees e
JOIN departments d
    ON e.department_id = d.department_id
ORDER BY d.department_name, salary_rank;


-- ============================================================
-- TASK 6: CASE Statement - Categorise Employees by Salary
-- Low: < 60000 | Medium: 60000 - 79999 | High: >= 80000
-- ============================================================
SELECT
    employee_id,
    employee_name,
    salary,
    CASE
        WHEN salary >= 80000 THEN 'High'
        WHEN salary >= 60000 THEN 'Medium'
        ELSE 'Low'
    END AS salary_category
FROM employees
ORDER BY salary DESC;

-- ============================================================
-- END OF SCRIPT
-- ============================================================
